README
Ece Yaykiran
101101184

Files Included:
  patioBuilder.c
  cards.c

Instructions to compile:
  Open terminal
  gcc -o patioBuilder patioBuilder.c -lm (for patioBuilder program)
  gcc -o cards cards.c (For cards program)

Instructions to run:
  ./patioBuilder
  ./cards

Notes:
For cards program, user input is asked in two parts(first rank followed by suit) & to quit program as well you will need to enter "." twice as input is seperated.
