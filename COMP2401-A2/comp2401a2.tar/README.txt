README
Ece Yaykiran
101101184

Files Included:
  encode.c
  decode.c
  corrupt.c
  fix.c

Instructions to compile:
  Open terminal
  gcc -o encode encode.c (for encode program)
  gcc -o decode decode.c (for decode program)
  gcc -o corrupt corrupt.c (for corrupt program)
  gcc -o fix fix.c (for fix program)

Instructions to run:
  ./encode
  ./decode
  ./corrupt
  ./fix

Instructions to run all files simultaneously:
./encode | ./corrupt | ./fix | ./decode
