README
Ece Yaykiran
101101184

Files Included:
  cellTower.c
  display.c
  generator.c
  simulator.c
  stop.c
  vehicle.c
  simulator.h	

Instructions to compile:
  Open terminal
  make

Instructions to run:
  ./simulator &
  ./generator &
  ./stop

